package com.hailong.amd.north;

import com.hailong.common.base.BaseApplication;

/**
 * Describe：
 * Created by ZuoHailong on 2019/4/19.
 */
public class NorthApplication extends BaseApplication {
}
