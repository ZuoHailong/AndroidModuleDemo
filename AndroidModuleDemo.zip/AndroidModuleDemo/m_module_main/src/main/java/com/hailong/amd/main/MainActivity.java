package com.hailong.amd.main;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.hailong.common.base.BaseActivity;

/**
 * Describe：
 * Created by ZuoHailong on 2019/4/19.
 */
@Route(path = "/main/MainActivity")
public class MainActivity extends BaseActivity {
    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
