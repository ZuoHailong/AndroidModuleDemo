package com.hailong.common.arouter.service;

import com.alibaba.android.arouter.facade.template.IProvider;

/**
 * Describe：
 * Created by ZuoHailong on 2019/4/15.
 */
public interface ISplashService extends IProvider {
    void toSplash();
}
